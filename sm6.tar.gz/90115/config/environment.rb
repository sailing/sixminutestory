# Be sure to restart your server when you modify this file

# Uncomment below to force Rails into production mode when
# you don't control web/app server and can't set it the proper way
# ENV['RAILS_ENV'] ||= 'production'

ENV['RECAPTCHA_PUBLIC_KEY'] = '6LcrJbwSAAAAAC0RBTTT1x6PZ94_IFLybRR7X4mM'
ENV['RECAPTCHA_PRIVATE_KEY'] = '6LcrJbwSAAAAAFmQC3QNWVxmp_PxdkTPetTJEJrP'

RPX_API_KEY = 'c37c053204545279866b1c267510c078a3c7ef6c'

# Specifies gem version of Rails to use when vendor/rails is not present
#RAILS_GEM_VERSION = '2.3.4' unless defined? RAILS_GEM_VERSION

# Bootstrap the Rails environment, frameworks, and default configuration
require File.join(File.dirname(__FILE__), 'boot')

Rails::Initializer.run do |config|
    
# Pagination
  config.gem 'mislav-will_paginate', 
      :lib => 'will_paginate', 
      :source => 'http://gems.github.com'
      
      
# Database
#  config.gem "mysql"
  
# Background Mailer
#  config.gem "adzap-ar_mailer", :lib => 'action_mailer/ar_mailer', :source => 'http://gems.github.com'

# Search        
 # config.gem(
  #   'thinking-sphinx',
  #   :lib     => 'thinking_sphinx',
  #   :version => '1.3.8'
  # )      

# Friendly ID
  config.gem "friendly_id"
 
 # Authentication Gems
  config.gem 'authlogic', :version => '>= 2.1.3'
  config.gem 'rpx_now', :version => '>= 0.6.12', :source => 'http://gemcutter.org'
  config.gem 'authlogic_rpx', :version => '>= 1.1.1', :source => 'http://gemcutter.org'

# Caching
  config.gem 'memcached-northscale', :lib => 'memcached'
  require 'memcached'
  
  # Settings in config/environments/* take precedence over those specified here.
  # Application configuration should go into files in config/initializers
  # -- all .rb files in that directory are automatically loaded.
  # See Rails::Configuration for more options.

  # Skip frameworks you're not going to use. To use Rails without a database
  # you must remove the Active Record framework.
  # config.frameworks -= [ :active_record, :active_resource, :action_mailer ]

  # Specify gems that this application depends on. 
  # They can then be installed with "rake gems:install" on new installations.
  # You have to specify the :lib option for libraries, where the Gem name (sqlite3-ruby) differs from the file itself (sqlite3)
  # config.gem "bj"
  # config.gem "hpricot", :version => '0.6', :source => "http://code.whytheluckystiff.net"
  # config.gem "sqlite3-ruby", :lib => "sqlite3"
  # config.gem "aws-s3", :lib => "aws/s3"

  # Only load the plugins named here, in the order given. By default, all plugins 
  # in vendor/plugins are loaded in alphabetical order.
  # :all can be used as a placeholder for all plugins not explicitly named
  # config.plugins = [ :exception_notification, :ssl_requirement, :all ]

  # Add additional load paths for your own custom dirs
  # config.load_paths += %W( #{RAILS_ROOT}/extras )

  # Force all environments to use the same logger level
  # (by default production uses :info, the others :debug)
  # config.log_level = :debug

  # Make Time.zone default to the specified zone, and make Active Record store time values
  # in the database in UTC, and return them converted to the specified local zone.
  # Run "rake -D time" for a list of tasks for finding time zone names. Comment line to use default local time.
  config.time_zone = 'Arizona'

  # The internationalization framework can be changed to have another default locale (standard is :en) or more load paths.
  # All files from config/locales/*.rb,yml are added automatically.
  # config.i18n.load_path << Dir[File.join(RAILS_ROOT, 'my', 'locales', '*.{rb,yml}')]
  # config.i18n.default_locale = :de

  # Your secret key for verifying cookie session data integrity.
  # If you change this key, all old sessions will become invalid!
  # Make sure the secret is at least 30 characters and all random, 
  # no regular words or you'll be exposed to dictionary attacks.
  config.action_controller.session = {
    :session_key => '_6ms_session',
    :secret      => '3410c440d2b2685a47cfdb39d376sfj843f43ff9352c47510103871943edb52d9410bc578ec6e6922e713a62e41e21aed293c4bc9eb7308616b2281cad74b54df7405b270c'
  }

  # Use the database for sessions instead of the cookie-based default,
  # which shouldn't be used to store highly confidential information
  # (create the session table with "rake db:sessions:create")
  config.action_controller.session_store = :active_record_store

  # Use SQL instead of Active Record's schema dumper when creating the test database.
  # This is necessary if your schema can't be completely dumped by the schema dumper,
  # like if you have constraints or database-specific column types
  # config.active_record.schema_format = :sql

  # Activate observers that should always be running
  # Please note that observers generated using script/generate observer need to have an _observer suffix
  # config.active_record.observers = :cacher, :garbage_collector, :forum_observer


end
