module VotesHelper
end
