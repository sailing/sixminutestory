require 'test_helper'

class PromptsHelperTest < ActionView::TestCase
end
