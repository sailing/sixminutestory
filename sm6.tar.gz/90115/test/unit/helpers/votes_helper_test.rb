require 'test_helper'

class VotesHelperTest < ActionView::TestCase
end
