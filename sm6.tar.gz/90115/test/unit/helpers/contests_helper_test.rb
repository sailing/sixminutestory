require 'test_helper'

class ContestsHelperTest < ActionView::TestCase
end
